import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeedbackComponent } from './PageComponets/feedback/feedback.component';
import { HomeComponent } from './PageComponets/home/home.component';
import { LoginComponent } from './PageComponets/login/login.component';
import { OnboardComponent } from './PageComponets/onboard/onboard.component';
import { SignupComponent } from './PageComponets/signup/signup.component';
import { FeebackGuard } from './Services/feeback.guard';
import { OnboardGuard } from './Services/onboard.guard';

const routes: Routes = [
  {
    path: '',
   component: HomeComponent,
   pathMatch: 'full',
  },
 {
   path: 'signup',
   component: SignupComponent,
   pathMatch: 'full',
 },
 {
   path: 'login',
   component: LoginComponent,
   pathMatch: 'full',
 },
 {
   path: 'admin',
   component: OnboardComponent,
   pathMatch: 'full',
   canActivate: [OnboardGuard]
 },
 {
   path: 'user-dashboard',
   component: FeedbackComponent,
   pathMatch: 'full',
   canActivate: [FeebackGuard]
 },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
