package com.competency_member_management.Login_Registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSignupApplicationTests {

	@Test
	void contextLoads() {
	}

}
