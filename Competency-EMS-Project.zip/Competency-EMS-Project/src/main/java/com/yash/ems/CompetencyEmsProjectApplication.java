package com.yash.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompetencyEmsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompetencyEmsProjectApplication.class, args);
	}

}
