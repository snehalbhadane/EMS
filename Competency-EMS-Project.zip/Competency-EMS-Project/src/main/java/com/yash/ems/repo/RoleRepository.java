package com.yash.ems.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ems.model.Role;
import com.yash.ems.model.User;


public interface RoleRepository extends JpaRepository<Role,Long> {

	Role findByroleName(String roleName);

	
	
}

